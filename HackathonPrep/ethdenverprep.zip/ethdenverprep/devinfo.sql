/*
 Navicat PostgreSQL Data Transfer

 Source Server         : HackathonPrep
 Source Server Type    : PostgreSQL
 Source Server Version : 90605
 Source Host           : smartthingsdeviceinfo.cbua5nvysd0c.us-east-2.rds.amazonaws.com:5432
 Source Catalog        : SmartThingsHackathon
 Source Schema         : public

 Target Server Type    : PostgreSQL
 Target Server Version : 90605
 File Encoding         : 65001

 Date: 06/02/2018 00:34:02
*/


-- ----------------------------
-- Table structure for devinfo
-- ----------------------------
DROP TABLE IF EXISTS "public"."devinfo";
CREATE TABLE "public"."devinfo" (
  "HUB_ID" char(1) COLLATE "pg_catalog"."default" NOT NULL,
  "DEVICE_TYPE" char(1) COLLATE "pg_catalog"."default" NOT NULL,
  "mW_PER_PCT" int2 NOT NULL,
  "MAX_DIMMABLE_PCT" int2 NOT NULL,
  "key_column" int8 NOT NULL DEFAULT nextval('devinfo_key_column_seq'::regclass)
)
;
ALTER TABLE "public"."devinfo" OWNER TO "timmah1991";

-- ----------------------------
-- Primary Key structure for table devinfo
-- ----------------------------
ALTER TABLE "public"."devinfo" ADD CONSTRAINT "devinfo_pkey" PRIMARY KEY ("key_column");
