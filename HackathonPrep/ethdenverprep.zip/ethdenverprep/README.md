# ethdenverprep
dimmer.sh is the primary control app for finding smart contracts, validating bid options and submitting API calls to smartthings API's

Replace dimmmer.sh with stateless python app for containerization before hackathon. Each node should be able to accept 500-1000 concurrent validate/bid requests from smartthings apps and allow a finalized trade to be brokered

All code in the /smartapps/ need to be initialized at https://graph-na04-useast2.api.smartthings.com/ide/apps to receive API calls. Use simulation mode for testing w/o publishing

Do not manually create files in /smartapps/, use the smartapps app manager to create a new app from template, push to github from the smartapps interface and THEN start modifying code locally. It can't import new apps without using the web interface