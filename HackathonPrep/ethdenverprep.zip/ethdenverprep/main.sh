#!/bin/bash
echo starting a stupid script
echo that some hackerman1333337 
echo thinks is pr-fuckin-neeto

while getopts a:k:u:d: option
do
    case "${option}"
    in
    u) APIURL=${OPTARG};;
    d) APIKEY=${OPTARG};;
    p) USERNAME=${OPTARG};;
    f) DEBUG=$OPTARG;;
    esac
done


function check_blockchain {
    #This function will check the eth blockchain for any power consumption-reduce smart contracts and then pass the contract ID to check_params

}

function check_params {
    #this function will kick off whenever check_blockchain finds an open contract and check postgres for device count, status, wattage, etc. 
    #It will then pass the maximum power redution and cost to submit_bid

    #todo: READ BULB AND PRICE CONFIG FROM POSTGRES

    #todo: READ CURRENT CONFIG FROM SMARTTHINGS

    #todo: PASS MAX KW/H REDUCTION TO SUBMIT_BID

}

function submit_bid {
    #this is where we submit our max power reduce and the price that we will charge (per second) for that recudion. We will receive a response from endpoint with a yes/no

}

function send_commands {
    #This function will make the API calls to actually dim/defer the power consumption through smartthings API
    #Pass the API Url as first param, api key as second, percentage as third

    #todo: add DIRECTION as a passable parameter to the function to allow reverse_commands to do its fucking thing

#curl -H "Authorization: Bearer $2" -X PUT "$1/switches/$4/$3"
curl -H "Authorization: Bearer $2" -X PUT "$1/switches/dim/$3"
echo "sending OFF command to "$1" with key "$2

    #todo: SEND UN-DO COMMAND TO reverse_commands 
    #todo: disable CRON job to prevent overlapping commands from executing

}

function reverse_commands {
    #This un-does the changes we make in send_commands and re-installs CRON after X amount of seconds have completed (and our contract is satisfied)
    #Send data in following format: reverse_commands %REDUCEDBY TIME_REDUCED_FOR APIKEY APIURL

    PERCENTAGEREDUCED=$1
    DIMTIMER=$2
    APIKEY=$3
    APIURL=$4

    (sleep $DIMTIMER && send_commands $APIURL $APIKEY $PERCENTAGEREDUCED brighten)


}