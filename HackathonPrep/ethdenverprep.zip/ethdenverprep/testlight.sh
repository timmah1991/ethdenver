#!/bin/bash
echo "starting a stupid script"
echo "that some hackerman1333337"
echo "thinks is pr-fuckin-neeto"

while getopts u:d: option
do
    case "${option}"
    in
    u) APIURL=${OPTARG};;
    d) APIKEY=${OPTARG};;
    esac
done

function send_commands {
    #This function will make the API calls to actually dim/defer the power consumption through smartthings API
    #Pass the API Url as first param and key as second
curl -H "Authorization: Bearer $2" -X PUT "$1/switches/on"
echo "sending ON command to "$1" with key "$2

}

send_commands $APIURL $APIKEY